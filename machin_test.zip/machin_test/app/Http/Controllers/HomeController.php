<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ShortLink;
use DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
         $shortLinks = ShortLink::latest()->get();
         $total_count = count($shortLinks);
         $duplicats = ShortLink::groupBy('link')->havingRaw('COUNT(link) > 1')->get();
         $duplicat_count = count($duplicats);
   
        return view('home', compact('total_count','duplicat_count'));
        
    }
}
