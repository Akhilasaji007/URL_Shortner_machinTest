<?php
  
namespace App\Http\Controllers;
   
use Illuminate\Http\Request;
use App\ShortLink;
  
class ShortLinkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $shortLinks = ShortLink::latest()->get();
   
        return view('shortenLink', compact('shortLinks'));
    }
     
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $request->validate([
           'link' => 'required|url',
           'title' => 'required'
        ]);
   
        $input['link'] = $request->link;
        $input['title'] = $request->title;
        $input['code'] = str_random(6);
   
        ShortLink::create($input);

        $shortLinkss = ShortLink::latest()->get();
        

        $data ='';
        foreach ($shortLinkss as $shortLinks)
            {
      
        $data .=' <tr>
                  <td>'.$shortLinks->title.'</td>
                  <td><a href="'.route('shorten.link', $shortLinks->code).'" id="shorturl_'.$shortLinks->id.'" target="_blank">'. route('shorten.link', $shortLinks->code).'</a></td>
                  <td>'.$shortLinks->link.'</td>
                  <td>'.$shortLinks->created_at.'</td>
                  <td><button class="badge badge-warning" id="'.$shortLinks->id.'" onclick="copyToClipboard(this)">Copy URL!</button></td> 
                 </tr>';

            }
      return $data;
  
     
    }
   
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function shortenLink($code)
    {
        $find = ShortLink::where('code', $code)->first();
   
        return redirect($find->link);
    }
}