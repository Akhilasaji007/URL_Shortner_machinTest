@extends('layouts.app')

@section('content')
  
<div class="container" style="padding-top: 100px;">
    <div class="card">
          @if (Session::has('success'))
                <div class="alert alert-success">
                    <p>{{ Session::get('success') }}</p>
                </div>
            @endif
      <div class="card-header">
        <form method="" id="urlForm" action="">
            @csrf

            <div class="input-group mb-3">
            <input type="text" name="title" id="title" class="form-control" placeholder="Enter Title" aria-label="Recipient's username" aria-describedby="basic-addon2" style="border:2px solid #3a4047">
           </div>

            <div class="input-group mb-3">
            <input type="text" name="link" id="data_url" class="form-control" placeholder="Enter URL" aria-label="Recipient's username" aria-describedby="basic-addon2" style="border:2px solid #3a4047">
            </div>

            <div class="input-group-append">
                <button class="btn btn-success" type="submit">Generate Shorten Link</button>
              </div>
        </form>
      </div>
     
          
           <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-dark" id="">
                        <thead>
                          <tr>
                           
                             <th>Title</th>
                             <th>Short Link</th>
                             <th>Link</th>
                             <th>Created on</th>
                             <th></th>
                          </tr>
                        </thead>
                        <tbody id="table_data">
                          
                           @foreach($shortLinks as $row)
                            <tr>
                           
                            <td>{{ $row->title }}</td>
                            <td><a href="{{ route('shorten.link', $row->code) }}" id="shorturl_{{$row->id}}" target="_blank">{{ route('shorten.link', $row->code) }}</a></td>
                            <td>{{ $row->link }}</td>
                            <td>{{ $row->created_at }}</td>
                            <td><button class="badge badge-warning" id="{{$row->id}}" onclick="copyToClipboard(this)">Copy URL!</button></td>
                        </tr>
                           
                           @endforeach
                     


                       </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              </div>
              </div>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>

   <script type="text/javascript">

    $('#urlForm').on('submit',function(event){
        event.preventDefault();

        link = $('#data_url').val();
        title = $('#title').val();
        $.ajax({
          url: "{{ url('/generate_short_url')}}",
          type:"post",
          data:{
            "_token": "{{ csrf_token() }}",
            link:link,
            title:title,
          },
          success:function(data){

             $("#table_data").text('');
             $("#table_data").html(data);
           
          },
         });
        });
      </script>

 <script>
  function copyToClipboard(val) {
   
        var copyText = $('#shorturl_'+val.id).attr('href');
        document.addEventListener('copy', function(e) {
          e.clipboardData.setData('text/plain', copyText);
          e.preventDefault();
       }, true);


        document.execCommand('copy');  
        console.log('copied text : ', copyText);
        alert('copied text: ' + copyText); 

    }
</script>
@endsection

