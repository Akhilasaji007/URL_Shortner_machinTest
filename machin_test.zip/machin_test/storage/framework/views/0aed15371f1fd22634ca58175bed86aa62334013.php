<?php $__env->startSection('content'); ?>
  <div class="main-panel">
          <div class="content-wrapper">
          <div class="row">
              <div class="col-sm-4 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h5>Total URLs</h5>
                    <div class="row">
                      <div class="col-8 col-sm-12 col-xl-8 my-auto">
                        <div class="d-flex d-sm-block d-md-flex align-items-center">
                          <h2 class="mb-0"><?php echo e($total_count); ?></h2>
                         
                        </div>
                       
                      </div>
                     
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-4 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h5>Duplicate URLs</h5>
                    <div class="row">
                      <div class="col-8 col-sm-12 col-xl-8 my-auto">
                        <div class="d-flex d-sm-block d-md-flex align-items-center">
                          <h2 class="mb-0"><?php echo e($duplicat_count); ?></h2>
                         
                        </div>
                        
                      </div>
                     
                    </div>
                  </div>
                </div>
              </div>
             
            </div>
         <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->

      <?php $__env->stopSection(); ?>


    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\machin_test\resources\views/home.blade.php ENDPATH**/ ?>